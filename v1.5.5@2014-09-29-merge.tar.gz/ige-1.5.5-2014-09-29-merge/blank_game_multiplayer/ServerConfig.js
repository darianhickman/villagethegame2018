var config = {
	include: [
		//{name: 'MyClassName', path: './gameClasses/MyClassFileName'},
	]
};

if (typeof(module) !== 'undefined' && typeof(module.exports) !== 'undefined') { module.exports = config; }