var IgeBox2dWorker = function () {
	// Setup initial variables
};