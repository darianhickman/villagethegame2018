# Startup Demo
This demo shows how to load a texture, ask the engine to tell us when all textures have loaded into memory, create a
scene, viewport and a custom entity class that is defined in the gameClasses/Rotator.js class which we use to make a
couple of fairy entities from.

This demo is a client-side only demo. Load the index.html file.