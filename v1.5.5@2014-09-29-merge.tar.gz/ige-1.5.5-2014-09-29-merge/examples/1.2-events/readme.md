# Events Demo
Tests the event system functionality and shows you how to register an event listener, emit an event and cancel an event
listener. This is a console-based test and doesn't output any graphics to the screen.