# Cell Sheets
This example shows you how to create a cell sheet texture by defining the grid area that the cells are arranged in.