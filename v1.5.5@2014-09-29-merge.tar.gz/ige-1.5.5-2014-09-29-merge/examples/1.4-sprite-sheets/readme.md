# Sprite Sheet Example
This example shows how to load a texture with defined rectangular areas that can be used as separate cell images.