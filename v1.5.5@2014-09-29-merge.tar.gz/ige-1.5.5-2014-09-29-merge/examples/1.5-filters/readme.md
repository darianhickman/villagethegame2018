# Filters Example
This example shows how to apply filters to textures to alter the texture image.