var MouseAim = function () {
	this.rotateToPoint(ige._currentViewport.mousePos());
};