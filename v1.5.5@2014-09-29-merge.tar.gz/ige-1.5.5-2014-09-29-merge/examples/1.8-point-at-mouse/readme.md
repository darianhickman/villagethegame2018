# Point At Mouse
This demo shows how to rotate an entity to point at the mouse position.

This demo is a client-side only demo. Load the index.html file.